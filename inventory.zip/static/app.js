/* app.js — 파나소닉 재고관리 공통 유틸리티 */
'use strict';

// ================================================
//  Toast 알림
// ================================================
function showToast(msg, type = 'success') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const c = document.getElementById('toast-container');
  if (!c) return;
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<span>${icons[type] || '📢'}</span><span>${msg}</span>`;
  c.appendChild(t);
  requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 320);
  }, 3400);
}

// ================================================
//  Modal helpers
// ================================================
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('active');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('active');
}
function closeAllModals() {
  document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) closeAllModals();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeAllModals();
});

// ================================================
//  AJAX helper
// ================================================
async function api(url, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  return res.json();
}

// ================================================
//  Button loading state
// ================================================
function setLoading(btnId, loading) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  if (loading) {
    btn.dataset.orig = btn.textContent;
    btn.textContent  = '처리 중…';
    btn.disabled     = true;
  } else {
    btn.textContent = btn.dataset.orig || '확인';
    btn.disabled    = false;
  }
}

// ================================================
//  실시간 테이블 검색
// ================================================
function initTableSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  const tbody = document.querySelector(`#${tableId} tbody`);
  if (!input || !tbody) return;
  input.addEventListener('input', () => {
    const kw = input.value.trim().toLowerCase();
    tbody.querySelectorAll('tr').forEach(row => {
      row.style.display =
        (kw === '' || row.textContent.toLowerCase().includes(kw)) ? '' : 'none';
    });
    updateRowCount(tableId);
  });
}

function updateRowCount(tableId) {
  const counter = document.getElementById(`${tableId}-count`);
  if (!counter) return;
  const visible = document.querySelectorAll(
    `#${tableId} tbody tr:not([style*="display: none"])`
  ).length;
  counter.textContent = `${visible}건`;
}

// ================================================
//  관리자 직원 관리 함수들
// ================================================
let _resetUid = null;

function openAddUserModal() {
  const f = document.getElementById('form-user');
  if (f) f.reset();
  openModal('modal-user');
}

async function submitUser() {
  const body = {
    username: document.getElementById('u-username').value.trim(),
    password: document.getElementById('u-password').value,
    name:     document.getElementById('u-name').value.trim(),
    role:     document.getElementById('u-role').value,
  };
  if (!body.username || !body.password || !body.name) {
    showToast('모든 항목을 입력해 주세요.', 'error'); return;
  }
  setLoading('btn-save-user', true);
  const res = await api('/api/admin/user', 'POST', body);
  setLoading('btn-save-user', false);
  if (res.success) {
    showToast(res.message, 'success');
    closeModal('modal-user');
    setTimeout(() => location.reload(), 700);
  } else { showToast(res.message || '오류', 'error'); }
}

async function toggleUser(uid) {
  const res = await api(`/api/admin/user/${uid}/toggle`, 'POST');
  if (res.success) { showToast(res.message, 'success'); setTimeout(() => location.reload(), 700); }
  else showToast(res.message || '오류', 'error');
}

function openResetPwModal(uid) {
  _resetUid = uid;
  const el = document.getElementById('new-password');
  if (el) el.value = '';
  openModal('modal-reset-pw');
}

async function confirmResetPw() {
  const pw = document.getElementById('new-password').value;
  if (!pw || pw.length < 4) { showToast('비밀번호는 4자 이상이어야 합니다.', 'error'); return; }
  setLoading('btn-confirm-pw', true);
  const res = await api(`/api/admin/user/${_resetUid}/password`, 'POST', { password: pw });
  setLoading('btn-confirm-pw', false);
  if (res.success) { showToast(res.message, 'success'); closeModal('modal-reset-pw'); }
  else showToast(res.message || '오류', 'error');
}

// ================================================
//  DOMContentLoaded
// ================================================
document.addEventListener('DOMContentLoaded', () => {
  ['tbl-products','tbl-history','tbl-audit','tbl-users'].forEach(id => {
    initTableSearch(`search-${id.replace('tbl-','')}`, id);
    updateRowCount(id);
  });
});
