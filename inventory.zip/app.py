#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
app.py — 파나소닉 용접로봇 재고관리 Flask 앱
"""

import socket
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify)
from werkzeug.security import check_password_hash
import database as db

app = Flask(__name__)
app.secret_key = 'panasonic_inv_secret_2024_change_me!'


# ─── Auth 데코레이터 ─────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            return jsonify({'success': False, 'message': '관리자 권한이 필요합니다.'}), 403
        return f(*args, **kwargs)
    return decorated


def client_ip():
    return request.headers.get('X-Forwarded-For', request.remote_addr or '')


def audit(action, target_type, target_id, target_name,
          before=None, after=None, note=''):
    db.add_audit_log(
        user_id=session.get('user_id'),
        user_name=session.get('user_name', ''),
        action=action,
        target_type=target_type,
        target_id=target_id,
        target_name=target_name,
        before_data=before,
        after_data=after,
        note=note,
        ip_address=client_ip()
    )


# ─── 로그인 / 로그아웃 ───────────────────────
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = db.get_user_by_username(username)
        if user and user['is_active'] and check_password_hash(user['password_hash'], password):
            session.update({
                'user_id':   user['id'],
                'user_name': user['name'],
                'username':  user['username'],
                'role':      user['role'],
            })
            audit('LOGIN', 'user', user['id'], user['name'])
            return redirect(url_for('dashboard'))
        error = '아이디 또는 비밀번호가 올바르지 않거나 비활성화된 계정입니다.'
    return render_template('login.html', error=error)


@app.route('/logout')
def logout():
    if 'user_id' in session:
        audit('LOGOUT', 'user', session['user_id'], session['user_name'])
    session.clear()
    return redirect(url_for('login'))


# ─── 대시보드 ────────────────────────────────
@app.route('/')
@login_required
def index():
    return redirect(url_for('dashboard'))


@app.route('/dashboard')
@login_required
def dashboard():
    stats     = db.get_stats()
    low_items = [p for p in db.get_all_products()
                 if p['quantity'] <= p['low_stock_alert']]
    recent    = db.get_audit_logs(limit=10)
    return render_template('dashboard.html',
                           stats=stats,
                           low_items=low_items,
                           recent=recent,
                           active='dashboard')


# ─── 재고 목록 ──────────────────────────────
@app.route('/products')
@login_required
def products():
    search   = request.args.get('search', '').strip()
    category = request.args.get('category', '전체')
    items      = db.get_all_products(search=search, category=category)
    categories = db.get_categories()
    return render_template('products.html',
                           items=items,
                           categories=categories,
                           search=search,
                           category=category,
                           active='products')


# ─── 상품 API ───────────────────────────────
@app.route('/api/product', methods=['POST'])
@login_required
def api_add_product():
    d = request.get_json(silent=True) or {}
    try:
        pid = db.add_product(
            item_code=d.get('item_code', '').strip(),
            name=d['name'].strip(),
            category=d['category'].strip(),
            model_spec=d.get('model_spec', '').strip(),
            price=int(d.get('price', 0)),
            quantity=int(d.get('quantity', 0)),
            unit=d.get('unit', '개').strip(),
            location=d.get('location', '').strip(),
            supplier=d.get('supplier', '').strip(),
            low_stock_alert=int(d.get('low_stock_alert', 10))
        )
        product = db.get_product(pid)
        audit('ADD', 'product', pid, d['name'], after=product)
        return jsonify({'success': True, 'message': f"'{d['name']}' 품목이 등록되었습니다."})
    except (KeyError, ValueError) as e:
        return jsonify({'success': False, 'message': f'입력 오류: {e}'}), 400


@app.route('/api/product/import-excel', methods=['POST'])
@login_required
def api_import_excel():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': '파일이 전송되지 않았습니다.'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': '선택된 파일이 없습니다.'}), 400
    if not file.filename.lower().endswith(('.xlsx', '.xls')):
        return jsonify({'success': False, 'message': '엑셀 파일(.xlsx, .xls)만 업로드할 수 있습니다.'}), 400
    
    try:
        inserted, skipped = db.import_excel_to_db(
            file.stream,
            user_id=session.get('user_id'),
            user_name=session.get('user_name', '시스템')
        )
        return jsonify({
            'success': True,
            'message': f'엑셀 가져오기가 완료되었습니다. (등록: {inserted}건, 스킵: {skipped}건)'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'엑셀 처리 중 오류 발생: {str(e)}'}), 500


@app.route('/api/product/update-prices-excel', methods=['POST'])
@login_required
def api_update_prices_excel():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': '파일이 전송되지 않았습니다.'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': '선택된 파일이 없습니다.'}), 400
    if not file.filename.lower().endswith(('.xlsx', '.xls')):
        return jsonify({'success': False, 'message': '엑셀 파일(.xlsx, .xls)만 업로드할 수 있습니다.'}), 400
    
    try:
        updated, no_change, no_match = db.update_prices_from_excel(
            file.stream,
            user_id=session.get('user_id', 0),
            user_name=session.get('user_name', '시스템')
        )
        return jsonify({
            'success': True,
            'message': f'단가 업데이트가 완료되었습니다. (업데이트: {updated}건, 변경없음: {no_change}건, 미매칭: {no_match}건)'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'단가 업데이트 중 오류 발생: {str(e)}'}), 500



@app.route('/api/product/<int:pid>', methods=['GET'])
@login_required
def api_get_product(pid):
    p = db.get_product(pid)
    if not p:
        return jsonify({'success': False}), 404
    return jsonify({'success': True, 'product': p})


@app.route('/api/product/<int:pid>', methods=['PUT'])
@login_required
def api_edit_product(pid):
    before = db.get_product(pid)
    if not before:
        return jsonify({'success': False, 'message': '품목을 찾을 수 없습니다.'}), 404
    d = request.get_json(silent=True) or {}
    try:
        db.update_product(pid,
            item_code=d.get('item_code', '').strip(),
            name=d['name'].strip(),
            category=d['category'].strip(),
            model_spec=d.get('model_spec', '').strip(),
            price=int(d.get('price', 0)),
            quantity=int(d.get('quantity', 0)),
            unit=d.get('unit', '개').strip(),
            location=d.get('location', '').strip(),
            supplier=d.get('supplier', '').strip(),
            low_stock_alert=int(d.get('low_stock_alert', 10))
        )
        after = db.get_product(pid)
        audit('EDIT', 'product', pid, d['name'], before=before, after=after)
        return jsonify({'success': True, 'message': f"'{d['name']}' 품목이 수정되었습니다."})
    except (KeyError, ValueError) as e:
        return jsonify({'success': False, 'message': f'입력 오류: {e}'}), 400


@app.route('/api/product/<int:pid>', methods=['DELETE'])
@login_required
def api_delete_product(pid):
    product = db.get_product(pid)
    if not product:
        return jsonify({'success': False, 'message': '품목을 찾을 수 없습니다.'}), 404
    db.delete_product(pid)
    audit('DELETE', 'product', pid, product['name'], before=product)
    return jsonify({'success': True, 'message': f"'{product['name']}' 품목이 삭제되었습니다."})


@app.route('/api/product/<int:pid>/stock-in', methods=['POST'])
@login_required
def api_stock_in(pid):
    product = db.get_product(pid)
    if not product:
        return jsonify({'success': False, 'message': '품목 없음'}), 404
    d = request.get_json(silent=True) or {}
    try:
        qty  = int(d.get('quantity', 0))
        note = d.get('note', '').strip()
        if qty <= 0: raise ValueError
    except (TypeError, ValueError):
        return jsonify({'success': False, 'message': '수량을 올바르게 입력해 주세요.'}), 400

    before_qty = product['quantity']
    db.stock_in(pid, qty)
    after = db.get_product(pid)
    audit('STOCK_IN', 'product', pid,
          f"[{product['item_code']}] {product['name']}",
          before={'quantity': before_qty},
          after={'quantity': after['quantity']},
          note=f"+{qty}{product['unit']}  {note}".strip())
    return jsonify({'success': True,
                    'message': f"입고 완료: +{qty} {product['unit']}",
                    'new_qty': after['quantity']})


@app.route('/api/product/<int:pid>/stock-out', methods=['POST'])
@login_required
def api_stock_out(pid):
    product = db.get_product(pid)
    if not product:
        return jsonify({'success': False, 'message': '품목 없음'}), 404
    d = request.get_json(silent=True) or {}
    try:
        qty  = int(d.get('quantity', 0))
        note = d.get('note', '').strip()
        if qty <= 0: raise ValueError
    except (TypeError, ValueError):
        return jsonify({'success': False, 'message': '수량을 올바르게 입력해 주세요.'}), 400

    before_qty = product['quantity']
    ok = db.stock_out(pid, qty)
    if not ok:
        return jsonify({'success': False,
                        'message': f"재고 부족! 현재 재고: {product['quantity']} {product['unit']}"}), 400

    after = db.get_product(pid)
    audit('STOCK_OUT', 'product', pid,
          f"[{product['item_code']}] {product['name']}",
          before={'quantity': before_qty},
          after={'quantity': after['quantity']},
          note=f"-{qty}{product['unit']}  {note}".strip())
    return jsonify({'success': True,
                    'message': f"출고 완료: -{qty} {product['unit']}",
                    'new_qty': after['quantity']})


# ─── 입출고 내역 ─────────────────────────────
@app.route('/history')
@login_required
def history():
    action = request.args.get('action', '')
    search = request.args.get('search', '').strip()
    raw  = db.get_audit_logs(limit=500, action_filter=action, search=search)
    logs = [l for l in raw if l['action'] in ('STOCK_IN', 'STOCK_OUT')]
    return render_template('history.html',
                           logs=logs,
                           action_filter=action,
                           search=search,
                           active='history')


# ─── 관리자 — 직원 관리 ─────────────────────
@app.route('/admin/users')
@login_required
def admin_users():
    if session.get('role') != 'admin':
        return redirect(url_for('dashboard'))
    users = db.get_all_users()
    return render_template('admin_users.html', users=users, active='admin_users')


@app.route('/api/admin/user', methods=['POST'])
@admin_required
def api_add_user():
    d = request.get_json(silent=True) or {}
    ok = db.create_user(
        username=d.get('username', '').strip(),
        password=d.get('password', ''),
        name=d.get('name', '').strip(),
        role=d.get('role', 'staff')
    )
    if ok:
        audit('ADD', 'user', None, d.get('name'))
        return jsonify({'success': True, 'message': f"'{d['name']}' 계정이 생성되었습니다."})
    return jsonify({'success': False, 'message': '이미 사용 중인 아이디입니다.'}), 400


@app.route('/api/admin/user/<int:uid>/toggle', methods=['POST'])
@admin_required
def api_toggle_user(uid):
    if uid == session.get('user_id'):
        return jsonify({'success': False, 'message': '본인 계정은 비활성화할 수 없습니다.'}), 400
    user = db.get_user_by_id(uid)
    if not user:
        return jsonify({'success': False, 'message': '사용자 없음'}), 404
    db.toggle_user_active(uid)
    state = '비활성화' if user['is_active'] else '활성화'
    audit('TOGGLE_USER', 'user', uid, user['name'], note=state)
    return jsonify({'success': True, 'message': f"'{user['name']}' 계정을 {state}했습니다."})


@app.route('/api/admin/user/<int:uid>/password', methods=['POST'])
@admin_required
def api_reset_password(uid):
    d    = request.get_json(silent=True) or {}
    user = db.get_user_by_id(uid)
    if not user:
        return jsonify({'success': False, 'message': '사용자 없음'}), 404
    db.update_user(uid, password=d.get('password', ''))
    audit('RESET_PW', 'user', uid, user['name'])
    return jsonify({'success': True, 'message': f"'{user['name']}' 비밀번호가 변경되었습니다."})


# ─── 관리자 — 감사 로그 ─────────────────────
@app.route('/admin/audit')
@login_required
def admin_audit():
    if session.get('role') != 'admin':
        return redirect(url_for('dashboard'))
    action_f = request.args.get('action', '')
    user_f   = request.args.get('user', '')
    search   = request.args.get('search', '').strip()
    logs     = db.get_audit_logs(limit=500, action_filter=action_f,
                                 user_filter=user_f, search=search)
    users    = db.get_all_users()
    return render_template('admin_audit.html',
                           logs=logs,
                           action_filter=action_f,
                           user_filter=user_f,
                           search=search,
                           users=users,
                           active='admin_audit')


# ─── 에러 핸들러 ─────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return render_template('login.html', error='페이지를 찾을 수 없습니다.'), 404


# ─── 진입점 ──────────────────────────────────
if __name__ == '__main__':
    db.init_db()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = '127.0.0.1'

    print()
    print("=" * 52)
    print("  [파나소닉 용접로봇 재고관리 시스템 시작]")
    print("=" * 52)
    print(f"  PC 접속:     http://127.0.0.1:5000")
    print(f"  스마트폰:    http://{local_ip}:5000")
    print(f"  초기 계정:   admin / admin1234")
    print("=" * 52)
    print()

    app.run(host='0.0.0.0', port=5000, debug=False)
